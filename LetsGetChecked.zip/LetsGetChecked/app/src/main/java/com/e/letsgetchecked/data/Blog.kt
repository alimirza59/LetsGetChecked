package com.e.letsgetchecked.data

/**
 * Created by Ali on 21/04/19
 */

//Bean class for Blogs
data class Blog(var posts :List<Post>,var comments : ArrayList<Comment>)

// Bean class for post
data class Post(val id: String,val title:String,val author: String,val publish_date : String,val slug:String,val description:String,val content:String)

// Bean class for Comments
data class Comment(val id:  String, var postId :String, var parent_id:String,var user :String,var date:String,var content :String)

