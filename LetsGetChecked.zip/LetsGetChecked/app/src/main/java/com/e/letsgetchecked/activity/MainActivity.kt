package com.e.letsgetchecked.activity

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.e.letsgetchecked.R
import com.e.letsgetchecked.callback.CustomCallback
import com.e.letsgetchecked.data.Blog
import com.e.letsgetchecked.data.Post
import com.e.letsgetchecked.databinding.ActivityMainBinding
import com.e.letsgetchecked.fragment.PostDetailFragment
import com.e.letsgetchecked.fragment.PostFragment
import com.e.letsgetchecked.network.ApiClient
import com.e.letsgetchecked.network.api.ApiInterface
import com.e.letsgetchecked.utils.CommonUtilities
import com.e.letsgetchecked.viewmodel.MainActivityViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Ali on 21/04/19
 */

class MainActivity : AppCompatActivity(), CustomCallback {
    // ViewModel Object to maintain state and data
    lateinit var mainActivityViewModel: MainActivityViewModel
    // Fragment showing list of Blogs
    lateinit var postFragment: PostFragment
    // Fragment showing blog content and comments
    lateinit var postDetailFragment: PostDetailFragment
    // Variable for DataBinding
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initializing DataBinding for Main Activity
        binding = DataBindingUtil.setContentView<ActivityMainBinding>(
            this, R.layout.activity_main
        )
        // Initializing Viewmodel object from ViewModelProvider
        mainActivityViewModel = ViewModelProviders.of(this).get(MainActivityViewModel::class.java)
        // Binding ViewModel to binding
        binding.viewModel = mainActivityViewModel
        // Forcing the framework to do so far everything for the binding
        binding.executePendingBindings()
        // Settting OnClicklistener on tap to retry  using lamda expression
        binding.txtRetry.setOnClickListener { getBlogData() }
        //Initialize all fragments
        setUpFragments()
        // Calling function to get all blogs
        getBlogData()
    }

    /*
     * Function to retrieve blogs from server
     * @return None
     */
    fun getBlogData() {
        // Checking Internet Connection before making Web Service Call
        if (CommonUtilities.isNetworkAvailable(baseContext)) {
            // Showing progress bar
            mainActivityViewModel.progress.set(true)
            // Hiding tap to retry text
            mainActivityViewModel.showRetry.set(false)
            val service: ApiInterface = ApiClient.getClient().create(ApiInterface::class.java)
            val call: Call<Blog> = service.getBlog()
            // Using Retrofit enqueue to make web service call in background thread
            call.enqueue(object : Callback<Blog> {
                override fun onResponse(call: Call<Blog>, response: Response<Blog>) {
                    //Dismissing progress bar
                    mainActivityViewModel.progress.set(false)
                    if (response.code() == ApiClient.STATUS_SUCCESS_CODE) {
                        // Storing response in ViewModel
                        mainActivityViewModel.blog = response.body()
                        // Sorting values based on date
                        mainActivityViewModel.blog?.posts =
                            mainActivityViewModel.blog?.posts!!.sortedWith(ComparePost).reversed()
                        // Replacing with blog fragment
                        replaceFragment(0, false)
                    }
                }

                override fun onFailure(call: Call<Blog>, t: Throwable) {
                    //Dismissing progress bar
                    mainActivityViewModel.progress.set(false)
                    // Showing Error on unsuccessful WebService call
                    CommonUtilities.showMessage(this@MainActivity, ApiClient.ERROR_MESSAGE)
                    // Showing tap to retry on Failure
                    mainActivityViewModel.showRetry.set(true)
                }
            })
        } else {
            //Dismissing progress bar
            mainActivityViewModel.progress.set(false)
            // Showing Error for no Internet Connection
            CommonUtilities.showMessage(this, ApiClient.NO_INTERNET_CONNECTION)
            // Showing tap to retry
            mainActivityViewModel.showRetry.set(true)
        }
    }

    /*
     * Function to replace fragment
     * @param id
     * 0: For Blog Fragment 1: For Comment Fragment
     *
     * @param onBack
     * true: For left to right animation
     * false: For right to left animation
     *
     * @param position
     * Position indicating blog index in the RecyclerView
     */
    fun replaceFragment(id: Int, onBack: Boolean, position: Int = 0) {
        // Initializing fragment transaction
        val transaction = supportFragmentManager.beginTransaction()
        // Animating fragment
        if (onBack)
            transaction.setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right)
        else
            transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left)
        // switch case for replacing fragment
        when (id) {
            0 -> {
                // replacing fragment using fragment transaction
                transaction.replace(R.id.fragmentContainer, postFragment)
            }
            1 -> {
                // Setting new position of a fragment if it is already initialized
                postDetailFragment.setPos(position)
                // replacing fragment using fragment transaction
                transaction.replace(R.id.fragmentContainer, postDetailFragment)
            }
        }
        // Commiting transaction
        transaction.commit()
    }

    /*
     * Comparator to sort values based on date
     */
    class ComparePost {
        companion object : Comparator<Post> {
            override fun compare(post1: Post, post2: Post): Int {
                val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
                val date1 = formatter.parse(post1.publish_date)
                val date2 = formatter.parse(post2.publish_date)
                return date1.compareTo(date2)
            }
        }
    }

    fun setUpFragments(){
        // Check if fragment is already initialized
        if (!::postFragment.isInitialized) {
            // Creating instance of PostFragment
            postFragment = PostFragment.newInstance()
            // Setting callbackListener between Fragment and Activity
            postFragment.setCallback(this)
        }
        // Check if fragment is already initialized
        if (!::postDetailFragment.isInitialized) {
            // Creating instance of PostDetailFragment
            postDetailFragment = PostDetailFragment.newInstance(0)
        }
    }

    /*
     * Function called when a Recycler item is clicked
     * @param position :- Clicked position of RecyclerView
     */
    override fun onClick(position: Int) {
        replaceFragment(1, false, position)
    }

    /*
     *Function to handle on back press
     */
    override fun onBackPressed() {
        // Check whether comment fragment is visible
        if (postDetailFragment.isVisible)
            //Replacing with Comment Fragment
            replaceFragment(0, true)
        else
            // Finishing activity if it is the last fragment
            finish()
    }
}
