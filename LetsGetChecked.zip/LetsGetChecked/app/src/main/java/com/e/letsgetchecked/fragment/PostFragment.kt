package com.e.letsgetchecked.fragment

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.e.letsgetchecked.R
import com.e.letsgetchecked.adapter.PostAdapter
import com.e.letsgetchecked.callback.CustomCallback
import com.e.letsgetchecked.databinding.FragPostBinding
import com.e.letsgetchecked.viewmodel.MainActivityViewModel

/**
 * Created by Ali on 21/04/19
 */

class PostFragment : Fragment(),CustomCallback{
    // ViewModel object containing Post data
    private lateinit var mainActivityViewModel: MainActivityViewModel
    // Variable to hold binding variable
    lateinit var binding : FragPostBinding
    // Variable for Activity Callback
    lateinit var customCallback: CustomCallback

    //Creating instance of the fragment
    companion object {
        /*
         *Function to create instance of PostFragment
         * @return instance of the fragment
         */
        fun newInstance(): PostFragment {
            return PostFragment()
        }
    }

    /*
     * Function to set Activity Callback
     * @param callback
     * Callback to call Activity function
     */
    fun setCallback(callback: CustomCallback){
        this.customCallback =callback
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Initializing Data Binding for the layout
        binding = DataBindingUtil.inflate(inflater, R.layout.frag_post,container,false)
        // Initializing ViewModel
        mainActivityViewModel = ViewModelProviders.of(activity!!).get(MainActivityViewModel::class.java)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        // Setting Layout manager for recycler view
        binding.postList.layoutManager =  LinearLayoutManager(activity)
        // Initializing adapter object for post
        binding.postList.adapter = PostAdapter(mainActivityViewModel.blog!!.posts,this)
    }

    /*
     * Function to handle callback of Recycler view
     * @param position
     * Position of clicked item of a Recyclerview
     */
    override fun onClick(position: Int) {
        // Sending callback to activity
        customCallback.onClick(position)
    }

}