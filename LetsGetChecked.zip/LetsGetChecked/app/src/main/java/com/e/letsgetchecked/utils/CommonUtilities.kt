package com.e.letsgetchecked.utils

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.support.design.widget.Snackbar
import android.view.View

/**
 * Created by Ali on 21/04/19
 */

class CommonUtilities {

    companion object {
        /*
        * Function to check internet Connection
        * @param context : Need Activity context
        */
        fun isNetworkAvailable(context: Context): Boolean {
            val cm: ConnectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            return cm.activeNetworkInfo != null
        }

        /*
        * Function to show  Success/ Error Messages
        * @param context : Need Activity context
        * @param message : Message to be shown
        */
        fun showMessage(context: Activity, message: String) {
            Snackbar.make(context.findViewById<View>(android.R.id.content), message, Snackbar.LENGTH_SHORT).show()
        }
    }
}