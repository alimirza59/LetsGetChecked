package com.e.letsgetchecked.network

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Created by Ali on 21/04/19
 */

class ApiClient {

    companion object {
        //Base Url for LetsGetChecked
        private const val BASE_URL = "https://raw.githubusercontent.com/LetsGetChecked/developer-challenge-api/master/api/"
        //Constant to show when no internet connection is available
        const val NO_INTERNET_CONNECTION = "No Internet Connection Available"
        //Constant to show when there is an unexpected error
        const val ERROR_MESSAGE = "Oops! Something went wrong"
        // Constant for status success
        const val STATUS_SUCCESS_CODE = 200

        /*
         * Function for building Retrofit Instance
         * @return Retrofit Instance
         */
        fun getClient(): Retrofit {
            return Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(OkHttpClient.Builder().build()).build()
        }
    }


}