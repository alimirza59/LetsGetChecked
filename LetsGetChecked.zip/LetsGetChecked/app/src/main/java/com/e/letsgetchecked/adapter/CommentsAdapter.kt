package com.e.letsgetchecked.adapter

import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.e.letsgetchecked.R
import com.e.letsgetchecked.callback.CustomCallback
import com.e.letsgetchecked.data.Comment
import com.e.letsgetchecked.databinding.CommentItemBinding

/**
 * Created by Ali on 21/04/19
 */

/*
 * Adapter for comments
 * @param commentList
 * List containing comments
 *
 * @param callback
 * Callback for Recycler Item Click
 */
class CommentsAdapter(var commentList: List<Comment>, val callback: CustomCallback) :
    RecyclerView.Adapter<CommentsAdapter.ViewHolder>(),
    CustomCallback {


    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        // Initializing Layout Inflater
        val layoutInflater: LayoutInflater = LayoutInflater.from(parent.context)
        // Initializing data binding on views
        val binding: CommentItemBinding = DataBindingUtil.inflate(layoutInflater, R.layout.comment_item, parent, false)
        // Binding current item position
        binding.position = position
        // Binding callback for recycler item click
        binding.handler = this

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Binding comment based on position
        holder.bind(commentList.get(position))
    }

    override fun getItemCount(): Int {
        // Setting size of recycler view
        return commentList.size
    }

    /*
     * ViewHolder for Recycler View
     * @param postItemBinding
     * Recycler item binding
     */
    class ViewHolder(val commentItemBinding : CommentItemBinding) : RecyclerView.ViewHolder(commentItemBinding.root) {

        /*
         * Function to bind comments
         * @param mComment
         * Bean class containing comment data
         */
        fun bind(mComment: Comment) {
            commentItemBinding.comment = mComment
        }
    }

    /*
     * Function ro handle onClick of recycler item
     * @param position
     * Position of clicked item
     *
     * @return None
     */
    override fun onClick(position: Int) {
        callback.onClick(position)
    }

    /*
     * Function to update comment list based on Position
     * @param List<Comment> List of new comments
     */
    fun setComment(mCommentList: List<Comment>) {
        // Updating adapter data with new list
        this.commentList = mCommentList
        // Notifying adapter about data change
        notifyDataSetChanged()
    }


}