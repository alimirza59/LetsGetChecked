package com.e.letsgetchecked.adapter

import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.e.letsgetchecked.R
import com.e.letsgetchecked.callback.CustomCallback
import com.e.letsgetchecked.data.Post
import com.e.letsgetchecked.databinding.PostItemBinding

/**
 * Created by Ali on 21/04/19
 */

/*
 * Adapter for post
 * @param postList
 * List containing post to be displayed on RecyclerView
 *
 * @param callback
 * Callback for Recycler Item Click
 */
class PostAdapter(private val postList: List<Post>, val callback: CustomCallback) : RecyclerView.Adapter<PostAdapter.PostViewHolder>(),CustomCallback {


    override fun onCreateViewHolder(parent: ViewGroup, position: Int): PostViewHolder {
        // Initializing Layout Inflater
        val layoutInflater: LayoutInflater = LayoutInflater.from(parent.context)
        // Initializing data binding on views
        val binding: PostItemBinding = DataBindingUtil.inflate(layoutInflater, R.layout.post_item, parent, false)
        // Binding callback for recycler item click
        binding.handler = this

        return PostViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        // Binding post based on position
        holder.bind(postList.get(position),position)
    }

    override fun getItemCount(): Int {
        // Setting size of recycler view
        return postList.size
    }

    /*
    * ViewHolder for Recycler View
    * @param postItemBinding
    * Recycler item binding
    */
    class PostViewHolder(val postItemBinding: PostItemBinding) : RecyclerView.ViewHolder(postItemBinding.root) {

        /*
         * Function to bind post
         * @param mPost
         * Bean class containing post data
         *
         * @param position
         * Position of current item
         */
        fun bind(mPost: Post,position: Int) {
            postItemBinding.post = mPost
            postItemBinding.position = position
        }
    }

    /*
    * Function ro handle onClick of recycler item
    * @param position
    * Position of clicked item
    *
    * @return None
    */
    override fun onClick(position: Int) {
        callback.onClick(position)
    }
}