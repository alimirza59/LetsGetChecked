package com.e.letsgetchecked.viewmodel

import android.arch.lifecycle.ViewModel
import android.database.Observable
import android.databinding.ObservableBoolean
import android.databinding.ObservableFloat
import com.e.letsgetchecked.data.Blog

/**
 * Created by Ali on 21/04/19
 */

class MainActivityViewModel : ViewModel(){

    // Observable Boolean for progress bar
    val progress = ObservableBoolean(false)

    // Observable boolean for showing / hiding comments section
    val showComment = ObservableBoolean(true)

    // Observable boolean to enable/disable comment post button
    val enablePost = ObservableBoolean(false)

    // Observable boolean to show tap to retry
    val showRetry = ObservableBoolean(false)

    // Observable float to set alpha value of comment post button
    val alpha = ObservableFloat(0.2f)

    // To store blog and comments
    var blog : Blog? = null
}