package com.e.letsgetchecked.network.api


import com.e.letsgetchecked.data.Blog
import retrofit2.http.GET
import retrofit2.Call

/**
 * Created by Ali on 21/04/19
 */

interface ApiInterface{

    // Function to retrieve all blogs
    @GET("db.json")
    fun getBlog() : Call<Blog>
}