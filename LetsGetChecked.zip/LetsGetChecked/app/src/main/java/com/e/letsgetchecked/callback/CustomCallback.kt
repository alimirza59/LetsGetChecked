package com.e.letsgetchecked.callback

/**
 * Created by Ali on 21/04/19
 */

interface CustomCallback {

    /*
     * Function to handle OnClick of Recycler view
     * @param position
     * Position of clicked item
     */
    fun onClick(position: Int)

    /*
     * Function to handle onTextChange
     * @param text
     * CharSequence of Edittext
     */
    fun onTextChanged(text : CharSequence){}

}