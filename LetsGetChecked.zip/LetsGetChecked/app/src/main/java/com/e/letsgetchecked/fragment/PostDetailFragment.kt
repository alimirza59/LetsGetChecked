package com.e.letsgetchecked.fragment

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.text.HtmlCompat
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.e.letsgetchecked.R
import com.e.letsgetchecked.adapter.CommentsAdapter
import com.e.letsgetchecked.callback.CustomCallback
import com.e.letsgetchecked.data.Comment
import com.e.letsgetchecked.databinding.FragPostDetailBinding
import com.e.letsgetchecked.viewmodel.MainActivityViewModel
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Ali on 21/04/19
 */


class PostDetailFragment : Fragment(), CustomCallback, View.OnClickListener {
    // Variable to hold binding
    lateinit var binding: FragPostDetailBinding
    // Variable indicating the current post
    private var position: Int = -1
    // ViewModel object containing Post and comment data
    private lateinit var mainActivityViewModel: MainActivityViewModel
    // boolean variable to check whether onCreate was called or not as fragment replace cause OnCreate to be called again
    private var isOnCreateCalled = false
    // Variable containing comments
    private lateinit var filteredComments: MutableList<Comment>
    // Variable for comments adapter
    private lateinit var commentsAdapter: CommentsAdapter

    //Creating instance of the fragment
    companion object {
        // Bundle key for current position
        const val POSITION: String = "position"

        /*
         *Function to create instance of PostFragment
         * @param mPosition
         * position indicating selected blog
         *
         * @return instance of the fragment
         */
        fun newInstance(mPosition: Int): PostDetailFragment {
            val postDetailFragment = PostDetailFragment()
            val args = Bundle()
            args.putInt(POSITION, mPosition)
            postDetailFragment.arguments = args
            return postDetailFragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Avoiding multiple calls to OnCreate
        if (!isOnCreateCalled) {
            // Retrieving arguments containing position
            val bundle: Bundle? = arguments
            position = bundle!!.getInt(POSITION)
            isOnCreateCalled = true
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Initializing Data Binding for the layout
        binding = DataBindingUtil.inflate(inflater, R.layout.frag_post_detail, container, false)
        // Initializing ViewModel
        mainActivityViewModel = ViewModelProviders.of(activity!!).get(MainActivityViewModel::class.java)
        // Binding ViewModel to data binding variable
        binding.viewModel = mainActivityViewModel
        // Binding callback to data binding variable
        binding.handler = this
        return binding.root
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        // Setting blog title
        binding.txtContentTitle.text = mainActivityViewModel.blog!!.posts.get(position).title
        // Initializing LayoutManger for Comments RecyclerView
        binding.commentList.layoutManager = LinearLayoutManager(activity)
        // Setting blog content and parsing html text
        binding.txtContent.text = HtmlCompat.fromHtml(
            mainActivityViewModel.blog!!.posts.get(position).content,
            HtmlCompat.FROM_HTML_MODE_LEGACY
        )
        // Filtering comments based on postId ans sorting based on Date
        filteredComments = mainActivityViewModel.blog!!.comments.filter {
            it.postId.equals(
                mainActivityViewModel.blog!!.posts.get(position).id, true
            )
        }.sortedWith(CompareComment).reversed().toMutableList()
        // Initializing Comment Adapter
        commentsAdapter = CommentsAdapter(filteredComments, this)
        // Stting adapter to Recycler view
        binding.commentList.adapter = commentsAdapter
        // Check if ther are no comments
        if (filteredComments.isEmpty())
            mainActivityViewModel.showComment.set(false)
        else
            mainActivityViewModel.showComment.set(true)
        // Setting Listener for posting comments
        binding.txtPostComment.setOnClickListener(this)
    }

    /*
     * Function to handle Recycler item click
     * @param position
     * Position of clicked item of Recycler view
     */
    override fun onClick(position: Int) {
        Log.d(javaClass.canonicalName, position.toString())
    }

    /*
     * Function to change position to load different post
     * @param mPosition
     * Position of selected post
     */
    fun setPos(mPosition: Int) {
        position = mPosition
    }

    /*
     * Comparator to sort values based on date
     */
    class CompareComment {
        companion object : Comparator<Comment> {
            override fun compare(comment1: Comment, comment2: Comment): Int {
                val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
                val date1 = formatter.parse(comment1.date)
                val date2 = formatter.parse(comment2.date)
                return date1.compareTo(date2)
            }
        }
    }

    override fun onClick(view: View?) {
        // Getting new comment to be posted
        var comment = binding.edtComment.text.toString().trimStart()
        // Check if comment is not empty
        if (comment.trim().isNotEmpty()) {
            // Initializing Calender instance
            val calendar = Calendar.getInstance().time
            // Initializing date format with English Locale
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
            // Formating current date
            val formattedDate = df.format(calendar)
            // Creating new comment
            var newComment = Comment(
                id = mainActivityViewModel.blog!!.posts.get(position).id,
                postId = mainActivityViewModel.blog!!.posts.get(position).id,
                parent_id = "1",
                user = "Ali Mirza",
                date = formattedDate,
                content = comment
            )
            // Adding new comment to the List
            filteredComments.add(0, newComment)
            // Updating comment list in ViewModel
            mainActivityViewModel.blog!!.comments.add(newComment)
            // Notifying Adapter about newly added comment
            commentsAdapter.setComment(filteredComments)
            // Showing comment title
            mainActivityViewModel.showComment.set(true)
            // Making Edittext blank after comment is posted
            binding.edtComment.setText("")
        }

    }

    /*
     * Function to perform when comment text is typed
     * @param text
     * CharSequence indicating current comment
     */
    override fun onTextChanged(text: CharSequence) {
        super.onTextChanged(text)
        // Check whether comment is in proper format
        if (text.toString().trimStart().isNotEmpty()) {
            // Enabling Post Button
            mainActivityViewModel.alpha.set(1.0f)
            mainActivityViewModel.enablePost.set(true)
        } else {
            // Disabling Post Button
            mainActivityViewModel.alpha.set(0.2f)
            mainActivityViewModel.enablePost.set(false)
        }
    }
}